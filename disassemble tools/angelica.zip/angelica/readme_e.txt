#=================================================================================
#	                Angelica  ver.2.0.6
#                                            Masashi Katsumata
#                                                      November 15, 2004
#
#                                    http://online.dip.jp/angelica/index_e.html
#=================================================================================
1:Description
    This program is disassembler for Ubicom(old name:Scenix).inc SX Series cpu.

2:Feature
    It can carry out disassemble for all CPUs of SX series.(SX18/20/28/48/52)
    A registry name can be defined personally.(INCLUDE FILE)

3:How to use
    Step 1    Select target hex file.
    Step 2    And select target sx cpu from left pictures.
    Step 3    Click [Start] button then start processing.

              If process is right then
              angelica will be print out 'filename.txt'.
              And lunch up your txt editor.

4:Options
    INC FILE  A registry name can be defined personally.
           Example: $ra        ->     PORTA
                    REG_10     ->     Counter

              Include file format:
                  <original name> = <registry address>    ;<comment>

              registry address format:
                  $hh,0xhh     ->      Hex number(Ex: $05 ,0x06)
                  d            ->      Decimal number(Ex: 10   (=0xA))
                  0oOO         ->      Oct number(Ex: 0o27 (=0x17))


     use the labels with the address value
              It can use the labels with the address value.
              Default set is use the labels width count value.
                       Address    Label    Mnemonic       Operand
                      ---------------------------------------------------------
                         0000               jmp           Label_0001
                         0001               mov           w,#$03
                                                   :
                         0100   Label_0001  mov           ra,w
                                                   :
              However,this option check then
              it can use the labels with the address value.
                        Address    Label    Mnemonic       Operand
                      ---------------------------------------------------------
                         0000               jmp           Label_0100
                         0001               mov           w,#$03
                                                   :
                         0100   Label_0100  mov           ra,w
                                                   :

5:Contact
    wf9a5m75@hotmail.com

6:Offical Site
    http://online.dip.jp/angelica/index_e.html

7:Warning & license
 * Masafumi Katsumata has this soft copyright.
	(C)2004 Masashi Katsumata
 * This software includes intellectual property rights.
   Reverse engineering, reverse assembling, reverse compile are all prohibited.
 * It allows re-distributing.
   However, I want you to connect.
 * This software is freeware now.

8:Special thanks
 * Angelo Pires
 * Kazuhiro Sasao
 * Sasao Ikushima
 * Joaquim Abreu

9:history
------------------------------------------------------------------------------
 November 15, 2004                      If the file did not suit SX then ask to user.

 October 17, 2004                       It corrected about the analysis of FUSE word.

 September 2, 2004                      It corrected about the analysis of FUSE word.

 September 1, 2004                      It corrected that print out registry list was wrong.

 August 30, 2004                        It corrected that print out registry list was wrong.

 August 29, 2004                        release version 2.
                                        Add support SX48/52.
------------------------------------------------------------------------------
 August 22, 2004                        Change soft name is 'Angelica'.
                                        It corrected that the 'ID' was wrong.
                                        It corrected that the 'jmp' and 'call' 
                                                         address were wrong.
                                        Add command line options.
                                                                      ...etc

 August 21, 2004                        It corrected that the 'org','ID' were wrong.
                                        Add 'reset' instraction.
                                                                      ...etc

 August 20, 2004                        It corrected important errors.
                                        It corrected that the 'retw' was wrong.
                                                                      ...etc

 August 16, 2004                        It corrected that the 'retw' and 'WDTE' were wrong.

 August 14, 2004                        It corrected that the '#lit()','n()',
                                          'fr()' and 'fr().bit' were wrong.
                                        Add 'mov w.fr-w','not w' and
                                           'mov w,--fr' instractions.
                                                                      ...etc

 August 13, 2004                        prototype release.
------------------------------------------------------------------------------